Reset_Countdown is a tool for simply clicking a button and having the time before WvW NA reset become displayed for you.

This is specifically designed for Guild Wars 2. It only tracks time for north america WvW reset too.

Expect some "lag" when you move it because the whole window is sleeping in the current version.

The current build should only work on windows 10. Sorry about that, I don't really have any others supported in first release at the moment.

Please let Ottohi know of any bugs/incompatabilities.